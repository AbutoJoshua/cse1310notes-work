public class square 
{
  public static void main(String[] args) 
  {
    double side_length = 10.0;
	//The variable side_length was being used before being declared and initiated.
    double square_area = side_length * side_length;
    System.out.println(square_area);
  }
}
