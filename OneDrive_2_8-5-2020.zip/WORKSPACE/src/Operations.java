public class Operations {
  public static void main(String[] args) {
    double x = 12.7743;
    x--;
    x += 2;
    System.out.printf("x = %.2f\n", x);
  }
}
//If you execute this program, what will be printed? Put your answer in your answers file. 