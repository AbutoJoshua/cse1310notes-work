//Task 3 (10 pts.)
public class StringLength {
  public static void main(String[] args) {
    String a = "hello";
    a += "!";
    a += "123";
    int b = a.length();
    System.out.printf("a = %s\n", a);
    System.out.printf("The length of a is %d characters.\n", b);
    System.out.printf("The length of a is %d characters.\n", a.length());
  }
}
//If you execute this program, what will be printed? Put your answer in your answers file. 