
public class rectangle {
	public static void main(String[] args)
	{
		double length = 5.5;
		int width = 4;
		double area = length * width;
		double perimeter = 2*length + 2*width;
		System.out.println(area);
		System.out.println(perimeter);
	}

}
