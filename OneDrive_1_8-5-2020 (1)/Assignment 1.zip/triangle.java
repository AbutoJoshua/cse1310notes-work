public class triangle 
{
  public static void main(String[] args) 
  {
    int base = 3;
    int height = 5;
    double area = height * base / 2.0;
    System.out.println(area);
  }
}
