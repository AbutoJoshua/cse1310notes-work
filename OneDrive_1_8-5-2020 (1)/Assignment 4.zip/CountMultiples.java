//Task 8

import java.util.Scanner;

public class CountMultiples 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an integer M: ");
		int M = sc.nextInt();
		
		System.out.print("Enter an integer M: ");
		int N = sc.nextInt();
		
		int count = 0;
		
		if( N > M)
		{
			for(int i = M; i <= N; i++)
			{
				if(i%11 == 0)
					count++;
			}
			System.out.printf("%d numbers between %d and %d are multiples of 11.", count, M, N);
			
		} else
		{
			System.out.printf("0 numbers between %d and %d are multiples of 11.", M, N);
		}
		
		System.out.print("\nExiting...");
		
		sc.close();
	}
}
