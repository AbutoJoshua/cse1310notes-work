//Task 1

public class WhileB
{
  public static void main(String[] args)
  {
    int a = 24;
    int b = 42;
    while (b != 0)
    {
      int t = b;
      b = a % b;
      a = t;
      System.out.printf("a = %3d, b = %3d\n", a, b);
    }
  }
}
