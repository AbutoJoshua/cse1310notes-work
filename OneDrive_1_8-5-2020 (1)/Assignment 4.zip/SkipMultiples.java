//Task 5

import java.util.Scanner;

public class SkipMultiples 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter low: ");
		int low = sc.nextInt();
		
		System.out.print("Enter high: ");
		int high = sc.nextInt();
		
		if( low <= high)
		{
			for(int i = low; i <= high; i++)
			{
				if (i%4 != 0 || (i ==low || i == high))
				{
					System.out.println(i);
				}
			}
		} else
		{
			System.out.print("no numbers found");
		}
		
		sc.close();
	}
}
