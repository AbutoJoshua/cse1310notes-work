//Task 6

import java.util.Scanner;

public class Stars
{
	public static void main(String[] args) 
	{ 
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter a positive integer N > 0: ");
		int N = sc.nextInt(); // can be 1 to 9
		
		if(N > 0)
		{
			for (int i = 1; i <= N; ++i)
			{
				// print digits 1 -> i
				for (int d = 1; d <= i; ++d)
				{
					System.out.print("*");
				}

				System.out.println();
			}
		} 
		
		System.out.print("Exiting...");
		
		
		
		sc.close();

	}
}
