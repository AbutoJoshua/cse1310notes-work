//Task 5

import java.util.Scanner;

public class PrintPowers
{
	public static void main(String[] args) 
	{ 
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter a positive integer N > 1: ");
		int N = sc.nextInt(); // can be 1 to 95
		if(N > 1)
		{
			int c = 0;
			
			while ( Math.pow(N, c) <= 40000)
			{
				System.out.println((int)Math.pow(N, c));
				c++;
				
			}
		}
		
		System.out.println("Exiting...");

		
		sc.close();
	}
}
