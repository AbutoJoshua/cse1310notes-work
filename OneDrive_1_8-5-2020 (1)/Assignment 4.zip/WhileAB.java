//Task 2

public class WhileAB
{
  public static void main(String[] args)
  {
    int a = 3;
    int b = 6;
    while (a < b)
    {
      a += 2;
      b++;
      System.out.printf("a = %d, b = %d\n", a, b);
    }
  }
}
