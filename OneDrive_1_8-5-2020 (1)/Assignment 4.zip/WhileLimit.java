//Task 3

public class WhileLimit
{
  public static void main(String[] args)
  {
    int a = 65;
    int limit = 50;
    while (a != limit)
    {
      a = limit - (limit-a)/2;
      System.out.printf("a = %2d\n", a);
    }
  }
}
