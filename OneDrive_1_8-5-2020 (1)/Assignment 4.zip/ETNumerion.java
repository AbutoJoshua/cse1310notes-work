//Task 4

import java.util.Scanner;

public class ETNumerion 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an integer N: ");
		int N = sc.nextInt();
		int i = 0;
		for(int j = N; j > 1; j--)
		{
			if(N%j == 0 && j*j + j == N)
			{
				i = j;
			}
			
		}
		
		if(i*i + i == N)
		{
			System.out.printf("%d is a holy number in Numerion.", N);
		} else
		{
			System.out.printf("%d is not a holy number in Numerion.", N);
		}
		
		System.out.print("\nExiting... ");
		
		sc.close();
	}

}
