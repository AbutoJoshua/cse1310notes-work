//Task 12

import java.util.Scanner;

public class MonthsToNumbers
{
	public static void main(String[] args)
	{
		Scanner cs = new Scanner(System.in);
		try 
		{
			System.out.print("Please enter the name of a month: ");
			String s = cs.nextLine();
			String s1 = s.toLowerCase();
			
			switch(s1)
			{
				case "january":
					System.out.print("January is the first month.");
					break;
				case "february":
					System.out.print("February is the second month.");
					break;
				case "march":
					System.out.print("March is the third month.");
					break;
				case "april":
					System.out.print("April is the fourth month.");
					break;
				case "may":
					System.out.print("May is the fifth month.");
					break;
				case "june":
					System.out.print("June is the sixth month.");
					break;
				case "july":
					System.out.print("July is the seventh month.");
					break;
				case "august":
					System.out.print("August is the eighth month.");
					break;
				case "september":
					System.out.print("September is the ninth month.");
					break;
				case "october":
					System.out.print("October is the tenth month.");
					break;
				case "november":
					System.out.print("November is the eleventh month.");
					break;
				case "december":
					System.out.print("December is the twelfth month");
					break;
				default:
					System.out.print("Unknown month: " + s);
					break;
			}
			
		} catch (RuntimeException e)
		{
			System.out.print("The entry did not match the requirements");

		} 
		
		
		cs.close();
	}
}
