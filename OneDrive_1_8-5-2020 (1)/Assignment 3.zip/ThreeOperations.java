// Task 9

import java.util.Scanner;

public class ThreeOperations
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Please enter real number N1: ");
		double N1 = sc.nextDouble();
		
		System.out.print("Please enter real number N2: ");
		double N2 = sc.nextDouble();

		System.out.printf("%.6f * %.6f = %.2f", N1, N2, N1*N2);
		System.out.printf("\n%.6f / %.6f = %.2f", N1, N2, N1/N2);
		System.out.printf("\n%.6f raised to the power of %.6f = %.2f", N1, N2, Math.pow(N1, N2));

		sc.close();
	}

}

