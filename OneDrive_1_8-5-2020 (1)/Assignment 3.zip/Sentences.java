// Task 8

import java.util.Scanner;

public class Sentences
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the first noun: ");
		String first_noun = sc.nextLine();
		
		System.out.print("Enter the second noun: ");
		String second_noun = sc.nextLine();

		System.out.print("Enter a verb: ");
		String verb = sc.nextLine();

		System.out.print("The " + first_noun + " " + verb + " over the " + second_noun + ".");
		
		sc.close();
	}
}
