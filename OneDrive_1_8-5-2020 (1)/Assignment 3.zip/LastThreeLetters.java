//Task 5

import java.util.Scanner;

public class LastThreeLetters 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		try
		{
			System.out.print("Please enter a string, at least 3 letters long: ");
		String s = sc.nextLine();
		
		String ending = s.substring(s.length()-3, s.length());
		System.out.println("The last three letters are " + ending);
		} catch (RuntimeException e)
		{
			System.out.print(e.getMessage());
		}
		
		
		sc.close();
	}
}
