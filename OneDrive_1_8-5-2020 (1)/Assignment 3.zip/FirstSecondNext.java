//Task 4

import java.util.Scanner;

public class FirstSecondNext 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Please enter a string, at least 5 letters long: ");
		String s = sc.nextLine();
		
		char first = s.charAt(0);
		char second = s.charAt(1);
		String next = s.substring(2, 5);
		
		
		System.out.println("The first letter of s is " + first);
		System.out.println("The second letter of s is " + second);
		System.out.println("The third, fourth, and fifth letters are " + next);
		
		sc.close();
	}

}
