//Task 15

import java.util.Scanner;

public class WordStart 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		try
		{
			System.out.print("Please enter a word: ");
			String word = sc.nextLine();
			
			char firstletter = word.charAt(0);
			
			if ("aeiouAEIOU".indexOf(firstletter)!= -1)
		    {
		        System.out.printf("%s starts with a vowel.\n", word);
		    } else if ("bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ".indexOf(firstletter) != -1)
		    {
		    	System.out.printf("%s starts with a constant.\n", word);
		    } else
		    {
		    	System.out.printf("%s starts with neither a vowel nor a consonant.\n", word);
		    }
			
			
		} catch (RuntimeException e)
		{
			System.out.println(e.getMessage());
		}
		
		sc.close();
	}
}
