//Task 6

import java.util.Scanner;

public class FourCapitalizations 
{
	public static void main(String[] args)
	{
		Scanner cs = new Scanner(System.in);
		
		System.out.print("Please enter a string: ");
		String s = cs.nextLine();
		String s1 = s.substring(0, 1);
		String s2 = s.substring(1);
		System.out.println("1st version: " + s);
		System.out.println("2nd version: " + s.toUpperCase());
		System.out.println("3rd version: " + s.toLowerCase());
		System.out.println("4th version: " + s1.toUpperCase() + s2.toLowerCase());
		
		cs.close();
	}
}
