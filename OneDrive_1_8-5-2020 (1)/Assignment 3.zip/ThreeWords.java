// Task 7
import java.util.Scanner;

public class ThreeWords
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Please enter an integer N: ");
		int n = sc.nextInt();
		
		System.out.print("Please enter a word with at least " + n + " and at most 20 letters: ");
		String firstN = sc.next();
		
		System.out.print("Please enter a second word with at least " + n + " and at most 20 letters: ");
		String secondN = sc.next();

		System.out.print("Please enter a third word with at least " + n + " and at most 20 letters: ");
		String thirdN = sc.next();

		System.out.printf("%20s starts with %s", firstN, firstN.substring(0, n)  );
		System.out.printf("\n%20s starts with %s", secondN, secondN.substring(0, n));
		System.out.printf("\n%20s starts with %s", thirdN, thirdN.substring(0, n));

		sc.close();
	}

}

		