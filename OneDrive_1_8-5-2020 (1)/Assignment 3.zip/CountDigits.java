//Task 13

import java.util.Scanner;

public class CountDigits
{
	public static void main(String[] args)
	{
		Scanner cs = new Scanner(System.in);
		try (Scanner sc = new Scanner(System.in))
		{
			System.out.print("Please enter an integer: ");
			int s = cs.nextInt();
			//String s1 = s.toLowerCase();
			
			if(s < 0)
			{
				System.out.print( s + " is negative.");
			} else if (s < 1000000)
			{
				if ( s > 99999)
				{
					System.out.print(s + " has six digits.");
				}else if(s > 9999)
				{
					System.out.print(s + " has five digits.");
				}else if(s > 999)
				{
					System.out.print(s + " has four digits.");
				}else if(s > 99)
				{
					System.out.print(s + " has three digits.");
				}else if(s > 9)
				{
					System.out.print(s + " has two digits.");
				}else if(s >= 0)
				{
					System.out.print( s + " has one digit.");
				}   
			} else
			{
				System.out.print(s + " has more than six digits.");
			}	
			
		} catch (RuntimeException e)
		{
			System.out.print("The entry did not match the requirements");

		} 
		
		
		cs.close();
	}
}
