//Task 14

import java.util.Scanner;

public class DivisibilityTests 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		try
		{
			System.out.print("Please enter an integer: ");
			int num = sc.nextInt();
			
			if(num < 0)
			{
				System.out.println("The number is negative.");
			}else if ( num % 2 == 0 && num % 3 == 0 )
			{
				System.out.println("The number is even and divisible by 3.");
			}else if ( num % 2 == 0 && num % 3 != 0 )
			{
				System.out.println("The number is even and not divisible by 3.");
			}else if ( num % 2 != 0 && num % 3 == 0 )
			{
				System.out.println("The number is odd and divisible by 3.");
			}else 
			{
				System.out.println("The number is odd and not divisible by 3.");
			}
			
		} catch (RuntimeException e)
		{
			System.out.println(e.getMessage());
		}
		
		sc.close();
	}

}
