//Task 10

import java.util.Scanner;

public class CountSeconds 
{
	public static void main(String[] args)
	{
		Scanner cs = new Scanner(System.in);
		try (Scanner sc = new Scanner(System.in))
		{
			int s;
			System.out.print("Please specify the number of seconds (between 1 and 86400): ");
			s = cs.nextInt();
			
			if (s <= 86400 && s >= 1)
			{
				int hours = s/3600;
				int minutes = (s%3600)/60;
				int seconds = (s%3600)%60;

				System.out.printf( s + " seconds correspond to %d hours, %d minutes, and %d seconds.", hours, minutes, seconds);
			} else
			{
				System.out.print("The number of seconds must be between 1 and 86400.");
			}

		} catch (RuntimeException e)
		{
			System.out.print("The entry did not match the requirements");

		} 
		
		
		cs.close();
	}
}
