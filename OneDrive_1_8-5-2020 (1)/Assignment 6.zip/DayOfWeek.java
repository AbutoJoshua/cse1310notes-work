//Task 6

import java.util.Scanner;

public class DayOfWeek
{
  
  public static int userInteger(String message)
  {
    Scanner in = new Scanner(System.in);
    int result;
    while (true)
    {
      System.out.printf(message);
      String s = in.next();
      if (s.equals("q"))
      {
        System.out.printf("Exiting...\n");
        in.close();
        System.exit(0);
      }
      
      try
      {
        result = Integer.parseInt(s);
      } 
      catch (Exception e)
      {
        System.out.printf("%s is not a valid number, try again.\n\n", s);
        continue;
      }
      
      if (result <= 0)
      {
        System.out.printf("%s is <= 0, try again.\n\n", s);
        continue;
      }
      return result;
    }
  }
  
  
  public static void main(String[] args) 
  {
//    Scanner in = new Scanner(System.in);
    
    while (true)
    {
      int year = userInteger("Enter a year (must be >= 1000): ");      
      if (year < 1000)
      {
        System.out.printf("Invalid year.\n\n");
        continue;
      }

      int month = userInteger("Enter a month(must be between 1 and 12): ");
      if (month > 12)
      {
        System.out.printf("Invalid month.\n\n");
        continue;
      }
      
      int day = userInteger("Enter a day: ");
      
      int result = daysPassed(year, month, day);
      System.out.printf("%d days have passed from 12/31/999 to %d/%d/%d.\n", 
                        result, month, day, year);
      
      String day_name = dayOfWeek(year, month, day);
      System.out.printf("%d/%d/%d is a %s.\n\n", month, day, year, day_name);
    }
    
  }
  
  public static int yearDays(int year)
	{
		int days;
		if (year % 100 == 0)
		{
			if (year % 400 == 0)
			{
				
				days = 366;
			}
			else
			{
				
				days = 365;
			}
		}
		else
		{
			if (year % 4 == 0)
			{
				
				days = 366;
			}
			else
			{
				
				days = 365;
			}
		}


		return days;
	}
  
  public static String dayOfWeek(int year, int month, int day)
  {
	  int days = daysPassed(year, month, day);
	  String dayofweek = "";
	  if (days%7 == 0)
	  {
		  dayofweek = "Tuesday";
	  } else if (days%7 == 1)
	  {
		  dayofweek = "Wednesday";
	  } else if (days%7 == 2)
	  {
		  dayofweek = "Thursday";
	  }  else if (days%7 == 3)
	  {
		  dayofweek = "Friday";
	  } else if (days%7 == 4)
	  {
		  dayofweek = "Saturday";
	  } else if (days%7 == 5)
	  {
		  dayofweek = "Sunday";
	  } else
	  {
		  dayofweek = "Monday";
	  }
	  
	  return dayofweek;
  }
  
  public static int daysPassed(int year, int month, int day)
  {
	  int dayspassed = 0;
	  if(year < 1000)
		  return dayspassed;
//	  int days = yearDays(year);
	  for(int i = 1000; i <= year; i++)
	  {
		  if(i != year)
		  {
			  for(int j = 1; j <= 12; j++)
			  {
				  dayspassed = dayspassed + monthDays(i, j);
			  }

		  } else
		  {
			  for(int j = 1; j < month; j++)
			  {
				  dayspassed = dayspassed + monthDays(i, j);
			  }
			  
			  dayspassed = dayspassed + day;
		  }
		  
	  }
	  return dayspassed;
  }
  
  public static int monthDays(int year, int month)
	{
		int monthdays;
		switch (month) {
		case 1:  monthdays = 31;
		break;
		case 2:  if(yearDays(year) == 366)
		{
			monthdays = 29;
		} else
		{
			monthdays = 28;
		}
		break;
		case 3:  monthdays = 31;
		break;
		case 4:  monthdays = 30;
		break;
		case 5: monthdays = 31;
		break;
		case 6:  monthdays = 30;
		break;
		case 7:  monthdays = 31;
		break;
		case 8:  monthdays = 31;
		break;
		case 9:  monthdays = 30;
		break;
		case 10: monthdays = 31;
		break;
		case 11: monthdays = 30;
		break;
		case 12: monthdays = 31;
		break;
		default: monthdays = 0;
		break;
		}
		
		return monthdays;
	}
}