// Task 3

import java.util.Scanner;

public class CountWords
{
  
  
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    
    while (true)
    {
      System.out.printf("Enter some text, or q to quit: ");
      String text = in.nextLine();
      if (text.equals("q"))
      {
        System.out.printf("Exiting...\n");
        break;
      }
      int result = countWords(text);
      System.out.printf("Counted %d words.\n\n", result);
    }
    
    
    in.close();
  }
  
  public static int countWords(String text)
  {
	  int word_count = 0;
	  
	  do
	  {
		  if(text.charAt(0) == ' ')
		  {
			  text = text.substring(1);
			  
		  }else
		  {
			  int j = 0;
			  while(j< text.length() && text.charAt(j) != ' ')
			  {		  
				  j++;
			  }
			  
			  text = text.substring(j);
			  
			  word_count = word_count + 1;
		  }
		  
	  }while (text.length() > 0);
	  
	  
	  
	  return word_count;
  }
}