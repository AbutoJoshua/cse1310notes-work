//Task 6
import java.util.Scanner;

public class Years
{
	public static void main(String[] args)
	{
		while (true)
		{
			int year = userInteger("Please enter a year >= 1, or q to quit: ");
			boolean result = isLeapYear(year);
			if (result == true)
			{
				System.out.printf("Yes, %d is a leap year.\n\n", year);
			} 
			else
			{
				System.out.printf("No, %d is not a leap year.\n\n", year);
			}
		}
	}
	// This function gets an integer from the user.
	// It ensures that the user enters a valid integer
	// that is >= 1.  
	public static int userInteger(String message)
	{
		Scanner in = new Scanner(System.in);
		int result;
		while (true)
		{
			System.out.printf(message);
			String s = in.next();
			if (s.equalsIgnoreCase("q"))
			{
				System.out.printf("Exiting...\n");
				System.exit(0);
			}
			
			try
			{
				if (Integer.parseInt(s) >= 1)
				{
					return Integer.parseInt(s);
				} else if (Integer.parseInt(s) <= 1)
				{
					System.out.printf("%s is not >= 1.\n", s);
				}
			} catch (RuntimeException e)
			{
				System.out.printf("%s is not a valid integer.\n\n", s);
			}
			
			// You need to complete the code for this function.
		}
		
	}
	
	public static boolean isLeapYear(int year)
	{
		if((year % 4 == 0 && year % 400 == 0) )
			return true;
		else if(year%4 == 0&& year % 100 == 0 )
			return false;
		else if((year % 4 == 0 ))
			return true;
		
		return false;
	}

}