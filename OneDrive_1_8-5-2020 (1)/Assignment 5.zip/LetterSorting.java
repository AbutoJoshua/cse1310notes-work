import java.util.Scanner;

public class LetterSorting
{

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		String text = "j";
		while (!(text.equalsIgnoreCase("q")))
		{
			System.out.printf("Enter some text, or q to quit: ");
			text = in.nextLine();
			if (text.toLowerCase().equals("q"))
			{
				System.out.printf("Exiting...\n");
				System.exit(0);
			}

			String result = sortLetters(text);
			System.out.printf("Result: %s.\n\n", result);
		}
		in.close();
	}

	public static String sortLetters(String text)
	{
		String dummy = "";
		text = text.toLowerCase();
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
		for (int i = 0; i<alphabet.length(); i++)
		{
			char c1 = alphabet.charAt(i);
			for (int j=0; j<text.length(); j++)
			{
				char c2 = text.charAt(j);
				if (c1==c2)
				{
					dummy +=c1;
				}
			}
		}
		return dummy;
	}
}