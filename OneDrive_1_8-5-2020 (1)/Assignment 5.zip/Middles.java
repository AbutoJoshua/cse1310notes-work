//Task 7
import java.util.Scanner;

public class Middles
{  

	public static void main(String[] args)
	{
		while (true)
		{
			double first = userDouble("please enter the first number, or q to quit: ");
			double second = userDouble("please enter the second number, or q to quit: ");
			double third = userDouble("please enter the third number, or q to quit: ");
			double middle = pickMiddle(first, second, third);
			System.out.printf("the middle value is %.1f\n\n", middle);
		}
	}
	// This function gets a double number from the user.
	// It ensures that the user enters a valid double number. 
	public static double userDouble(String message)
	{
		Scanner in = new Scanner(System.in);
		double result;
		String s = "f";
		System.out.printf(message);
		while (!(s.equalsIgnoreCase("q")))
		{
			s = in.next();
			try
			{

				if (Double.parseDouble(s) >= 0 || Double.parseDouble(s) <= 0)
				{
					result = Double.parseDouble(s);
					return result;
				}
			} catch(RuntimeException e)
			{
				if (s.equalsIgnoreCase("q"))
				{
					System.out.printf("Exiting...\n");
					System.exit(0);
				}
				System.out.print(s + " is not a valid double.\n\n");
				in.close();
				System.exit(0);
			}
		}

		return 0;

	}
	//This functions finds the median of the three values and returns it. 
	//If there are two or more numbers that are repeated it will return that value - the mode (the one that appears the most)
	public static double pickMiddle(double first, double second, double third)
	{
		if((first > second && first < third) || (first < second && first > third))
			return first;
		if((second > first && second < third) || (second < first && second > third))
			return second;
		if((third > second && third < first) || (third < second && third > first))
			return third;
		if(first == second)
			return first;
		if (second == third)
			return second;
		if (first == third)
			return third;

		return second;
	}
}
