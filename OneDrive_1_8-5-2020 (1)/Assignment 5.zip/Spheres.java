//Task 5
import java.util.Scanner;

public class Spheres
{
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args)
	{
		while(true)
		{
			double r = userDouble("Please enter a radius >= 0, or q to quit: ");

			double volume = sphereVolume(r);
			System.out.printf("Volume = %.2f.\n\n", volume);
		}
		// This function gets a double number from the user.
		// It ensures that the user enters a valid double number 
		// that is >= 0.
	}

	public static double sphereVolume(double radius)
	{
		double volume = 4 * Math.PI * Math.pow(radius, 3)/3;
		return volume;

	}

	public static double userDouble(String message)
	{

		double result;
		String s = "f";
		while (!(s.equalsIgnoreCase("q")))
		{
			System.out.printf(message);
			s = in.next();
			try
			{
				
				if (Double.parseDouble(s) >= 0)
				{
					result = Double.parseDouble(s);
					return result;
				} else if (Double.parseDouble(s) <= 0)
				{
					System.out.print(s + " is not positive.\n\n");
					s = "not";
					continue;
				}
//				else
//				{
//					System.out.print(s + " is not a valid double.\n\n");
//					continue;
//				}
			} catch(RuntimeException e)
			{
				if (s.equalsIgnoreCase("q"))
				{
					continue;
				}
				System.out.print(s + " is not a valid double.\n\n");
				
			}


		}

		System.out.printf("Exiting...\n");
		System.exit(0);
		return 0;

	}



}

